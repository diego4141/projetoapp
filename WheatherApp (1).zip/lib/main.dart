import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Previsão do Tempo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  String _city = "";
  String _weather = "";
  String _temperature = "";

  // Chave da API OpenWeatherMap
  String _apiKey = "7c47e16eb8219ea201e8a69baaf42c37"; // Sua chave aqui

  // Função para buscar o clima com base na latitude e longitude
  Future<void> _getWeather(double lat, double lon) async {
    final url =
        'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$_apiKey&units=metric&lang=pt_br';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _city = data['name'];
          _weather = data['weather'][0]['description'];
          _temperature = "${data['main']['temp'].toString()} °C";
        });
      } else {
        setState(() {
          _weather = "Erro ${response.statusCode}: ${response.reasonPhrase}";
        });
      }
    } catch (e) {
      setState(() {
        _weather = "Erro ao se conectar: $e";
      });
    }
  }

  // Função temporária para testar a API
  // Você pode usar geolocalização para pegar a lat/long real
  void _fetchWeather() {
    // Exemplo: latitude e longitude de São Paulo, Brasil
    double lat = -23.5505;
    double lon = -46.6333;
    _getWeather(lat, lon);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Previsão do Tempo'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              _city.isNotEmpty
                  ? "Cidade: $_city"
                  : "Pressione o botão para buscar o clima",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Text(
              _weather.isNotEmpty ? "Clima: $_weather" : "",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Text(
              _temperature.isNotEmpty ? "Temperatura: $_temperature" : "",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: _fetchWeather,
              child: Text('Buscar Clima'),
            ),
          ],
        ),
      ),
    );
  }
}
